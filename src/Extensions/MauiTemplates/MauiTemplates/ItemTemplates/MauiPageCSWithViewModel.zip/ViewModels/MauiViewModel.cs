﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.ComponentModel;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : BaseViewModel
    {
        
    }
}
