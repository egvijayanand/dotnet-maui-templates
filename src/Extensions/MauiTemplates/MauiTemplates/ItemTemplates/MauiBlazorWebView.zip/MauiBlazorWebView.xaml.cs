﻿namespace $rootnamespace$
{
    public partial class $safeitemname$ : ContentPage
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
