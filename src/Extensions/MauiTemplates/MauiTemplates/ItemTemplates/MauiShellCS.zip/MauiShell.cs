﻿namespace $rootnamespace$
{
    public partial class $safeitemname$ : Shell
    {
        public $safeitemname$()
        {
            // Flyout Items
            //Items.Add(new FlyoutItem()
            //{
            //    Title = "",
            //    Items =
            //    {
            //        new ShellContent()
            //        {
            //            ContentTemplate = new DataTemplate(typeof(ContentPage)),
            //            Route = "",
            //        },
            //    }
            //});

            // Menu Items
            //Items.Add(new MenuItem()
            //{
            //    Text = "",
            //}.Invoke(x => x.Clicked += OnMenuItemClicked));

            //TabBar Items
            //Items.Add(new TabBar()
            //{
            //    Title = "",
            //    Items =
            //    {
            //        new ShellContent()
            //        {
            //            ContentTemplate = new DataTemplate(typeof(ContentPage)),
            //            Route = "",
            //        },
            //    }
            //});
        }

        //private void OnMenuItemClicked(object sender, EventArgs e)
        //{
        //    
        //}
    }
}
