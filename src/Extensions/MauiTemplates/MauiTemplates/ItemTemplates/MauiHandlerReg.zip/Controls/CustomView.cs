﻿namespace $rootnamespace$
{
    public partial class $safeitemname$ : View, I$safeitemname$
    {
        public $safeitemname$()
        {
            
        }
    }
}
