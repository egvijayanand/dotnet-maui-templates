﻿namespace $rootnamespace$
{
    public partial class $safeitemname$ : ResourceDictionary
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
