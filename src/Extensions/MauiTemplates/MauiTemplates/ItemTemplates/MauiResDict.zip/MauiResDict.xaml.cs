﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Controls.Xaml;

namespace $rootnamespace$
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class $safeitemname$ : ResourceDictionary
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
