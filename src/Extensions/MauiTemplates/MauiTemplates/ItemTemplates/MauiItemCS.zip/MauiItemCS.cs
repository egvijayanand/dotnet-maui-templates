﻿namespace $rootnamespace$
{
    public partial class $safeitemname$ : $basetype$
    {
        public $safeitemname$()
        {
            
        }
    }
}
