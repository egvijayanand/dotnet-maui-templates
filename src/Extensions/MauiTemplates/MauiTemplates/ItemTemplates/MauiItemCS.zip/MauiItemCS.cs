﻿namespace $rootnamespace$;

public partial class $safeitemname$ : $base_type$
{
    public $safeitemname$()
    {
        
    }
}
