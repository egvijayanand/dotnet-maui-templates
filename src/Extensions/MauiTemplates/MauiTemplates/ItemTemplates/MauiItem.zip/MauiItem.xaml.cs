﻿namespace $rootnamespace$
{
    public partial class $safeitemname$ : $csbasetype$
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
