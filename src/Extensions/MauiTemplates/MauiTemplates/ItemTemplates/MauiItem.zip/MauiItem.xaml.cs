﻿namespace $rootnamespace$;

public partial class $safeitemname$ : $base_type_cs$
{
    public $safeitemname$()
    {
        InitializeComponent();
    }
}
