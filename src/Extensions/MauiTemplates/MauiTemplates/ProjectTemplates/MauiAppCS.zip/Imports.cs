﻿// Markup
global using CommunityToolkit.Maui.Markup;
global using VijayAnand.MauiToolkit.Markup;
// Static
global using static Microsoft.Maui.Graphics.Colors;
global using static CommunityToolkit.Maui.Markup.GridRowsColumns;
global using static VijayAnand.MauiToolkit.Markup.Utility;