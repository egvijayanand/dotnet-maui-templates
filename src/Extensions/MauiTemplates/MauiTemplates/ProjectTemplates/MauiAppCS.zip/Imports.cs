﻿// Markup
global using CommunityToolkit.Maui.Markup;
// Static
global using static Microsoft.Maui.Graphics.Colors;
global using static CommunityToolkit.Maui.Markup.GridRowsColumns;