﻿namespace $safeprojectname$
{
    public partial class App : Application
    {
        public App()
        {
            Build();

            MainPage = new MainPage();
        }
        
        private void Build()
        {
            Resources.Add("PrimaryColor", Color.FromArgb("#512BDF"));
            Resources.Add("SecondaryColor", White);

            Resources.Add(new Style(typeof(Label))
            {
                Setters =
                {
                    new() { Property = Label.TextColorProperty, Value = Resources["PrimaryColor"] },
                    new() { Property = Label.FontFamilyProperty, Value = "OpenSansRegular" }
                }
            });

            Resources.Add(new Style(typeof(Button))
            {
                Setters =
                {
                    new() { Property = Button.TextColorProperty, Value = Resources["SecondaryColor"] },
                    new() { Property = Button.FontFamilyProperty, Value = "OpenSansRegular" },
                    new() { Property = Button.BackgroundColorProperty, Value = Resources["PrimaryColor"] },
                    new() { Property = Button.PaddingProperty, Value = new Thickness(14,10) }
                }
            });
        }
    }
}
