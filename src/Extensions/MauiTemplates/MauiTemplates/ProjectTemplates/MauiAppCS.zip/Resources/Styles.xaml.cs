﻿namespace $safeprojectname$
{
    public partial class Styles : ResourceDictionary
    {
        public Styles()
        {
            InitializeComponent();
        }
    }
}
