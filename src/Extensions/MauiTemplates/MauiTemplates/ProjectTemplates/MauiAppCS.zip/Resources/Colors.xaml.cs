﻿namespace $safeprojectname$
{
    public partial class Colors : ResourceDictionary
    {
        public Colors()
        {
            InitializeComponent();
        }
    }
}
