﻿using System;
using Microsoft.Maui.Controls;

namespace $ext_safeprojectname$
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}
