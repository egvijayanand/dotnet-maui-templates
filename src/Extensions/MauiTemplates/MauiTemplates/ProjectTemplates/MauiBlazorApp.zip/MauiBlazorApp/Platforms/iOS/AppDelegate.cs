﻿using Foundation;
using Microsoft.Maui;

namespace $ext_safeprojectname$
{
	[Register("AppDelegate")]
	public class AppDelegate : MauiUIApplicationDelegate<Startup>
	{
	}
}