﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class Class1
    {
#if ANDROID
        // Code block for Android
#elif IOS
        // Code block for iOS
#elif MACCATALYST
        // Code block for Mac Catalyst
#elif WINDOWS
        // Code block for Windows
#endif
    }
}
